import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SampleSreamClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("----------int Stream-------------");
		
		Stream <Integer> myStream = Stream.of(10,20,30,40,50);
		List <Integer> myList = myStream.collect(Collectors.toList());
		System.out.println(myList);
		
		System.out.println("-------------Integer Stream----------");
		Stream <Integer> myStream1 = Stream.of(new Integer[] {100,200,300,400});
		List <Integer> myList1 = myStream1.collect(Collectors.toList());
		System.out.println(myList1);

		System.out.println("----------------ArrayListStream------------");
		List <Integer> myAList = new ArrayList<Integer>();
		for(int i=0;i<100;i++)
		{
			myAList.add(i);
		}

		System.out.println("-----------Sequential Stream of ArrayList-Integer-------");
		Stream <Integer> seqStream = myAList.stream();
		List <Integer> seqList = seqStream.collect(Collectors.toList());
		System.out.println(seqList);

		System.out.println("-----------Parallel Stream of ArrayList-Integer-------");
		Stream <Integer> paralStream = myAList.parallelStream();
		List <Integer> parList = paralStream.collect(Collectors.toList());
		System.out.println(parList);
		
		
		
	}

}
