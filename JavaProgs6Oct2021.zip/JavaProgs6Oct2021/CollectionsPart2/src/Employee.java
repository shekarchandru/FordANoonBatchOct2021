import java.util.Comparator;

public class Employee 
{
	String employeeId;
	String employeeCity;
	int employeeSalary;
	
	
	public Employee() {
		super();
	}


	public Employee(String employeeId, String employeeCity, int employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeCity = employeeCity;
		this.employeeSalary = employeeSalary;
	}


	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeCity=" + employeeCity + ", employeeSalary="
				+ employeeSalary + "]";
	}
	
}
//IDSORTER
class IdSorter implements Comparator <Employee>
{

	@Override
	public int compare(Employee e1, Employee e2) {
		// TODO Auto-generated method stub
		if((e1.employeeId.compareTo(e2.employeeId))>0)
		{
			return 1;
		}
		else if ((e1.employeeId.compareTo(e2.employeeId))<0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
}
//CITY SORTER
class CitySorter implements Comparator <Employee>
{

	@Override
	public int compare(Employee e1, Employee e2) {
		// TODO Auto-generated method stub
		if((e1.employeeCity.compareTo(e2.employeeCity))>0)
		{
			return 1;
		}
		else if ((e1.employeeCity.compareTo(e2.employeeCity))<0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
}
//SalarySorter
class SalarySorter implements Comparator <Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		if( o1.employeeSalary > o2.employeeSalary)
		{
			return 1;
		}
		else if( o1.employeeSalary < o2.employeeSalary)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
}
