import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class StudentSorter {

	/*public void populateStudents()
	{
		
	}
	public void fetchStudents()
	{
		
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student("S003","Bangalore",86);
		Student s2 = new Student("S007","Ahmedabad",80);
		Student s3 = new Student("S005","Faridabad",92);
		Student s4 = new Student("S001","Chennai",76);
		Student s5 = new Student("S002","Ernakulam",91);
		Student s6 = new Student("S004","Gauhati",69);
		Student s7 = new Student("S006","Dharwad",65);
		
		ArrayList <Student> students = new ArrayList<Student>();
		
		students.add(s1);
		students.add(s2);
		students.add(s3);
		students.add(s4);
		students.add(s5);
		students.add(s6);
		students.add(s7);
		
		/*Collections.sort(students);*/
		
		students.sort(null);
		
		Iterator <Student> studIter = students.iterator();
		while(studIter.hasNext())
		{
			Student student = studIter.next();
			System.out.println("Student "+student);
		}
		

	}

}
