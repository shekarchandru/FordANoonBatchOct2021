import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class EmployeeSorter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Employee> employees = new ArrayList <Employee> ();
		
		Employee e1 = new Employee("E003","Bangalore",8600);
		Employee e2 = new Employee("E007","Ahmedabad",8000);
		Employee e3 = new Employee("E005","Faridabad",9200);
		Employee e4 = new Employee("E001","Chennai",7600);
		Employee e5 = new Employee("E002","Ernakulam",9100);
		Employee e6 = new Employee("E004","Gauhati",6900);
		Employee e7 = new Employee("E006","Dharwad",6500);
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);
		employees.add(e6);
		employees.add(e7);
		System.out.println("Employee ID Sorted.....");
		
		Collections.sort(employees,new IdSorter());
		Iterator <Employee> idIter = employees.iterator();
		while(idIter.hasNext())
		{
			Employee e = idIter.next();
			System.out.println("Employee "+e);
		}
		
		System.out.println("Employee City Sorted.....");
		
		Collections.sort(employees,new CitySorter());
		Iterator <Employee> cityIter = employees.iterator();
		while(cityIter.hasNext())
		{
			Employee e = cityIter.next();
			System.out.println("Employee "+e);
		}
		
		System.out.println("Employee Salary Sorted.....");
		
		Collections.sort(employees,new SalarySorter());
		Iterator <Employee> salIter = employees.iterator();
		while(salIter.hasNext())
		{
			Employee e = salIter.next();
			System.out.println("Employee "+e);
		}


	}

}
