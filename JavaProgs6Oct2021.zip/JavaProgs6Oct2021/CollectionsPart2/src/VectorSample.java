import java.util.Enumeration;
import java.util.Vector;

public class VectorSample {

	Vector cVectors = new Vector(5,10);
	public void populateVector()
	{
		
		Customer c1 = new Customer("C001","Harsha","RTNagar",10000,12.34f);
		Customer c2 = new Customer("C002","SreeHarsha","Koramangala",12000,12.56f);
		Customer c3 = new Customer("C003","Harshitha","VijayaNagar",15000,15.34f);
		Customer c4 = new Customer("C004","HarshaVardhan","JayaNagar",20000,20.34f);
		cVectors.add(c1);
		cVectors.add(c2);
		cVectors.add(c3);
		cVectors.add(c4);
		cVectors.add(new Customer("C005","Kiran","Malleswaram",25000,25.34f));
		System.out.println("Size is :"+cVectors.size());
		System.out.println("Capacity  is :"+cVectors.capacity());
		cVectors.add(new Customer("C006","Kiran","Malleswaram",25000,25.34f));
		cVectors.add(new Customer("C007","Kishan","Indiranagar",25000,25.34f));
		cVectors.add(new Customer("C008","Suman","Malleswaram",25000,25.34f));
		cVectors.add(new Customer("C009","Sumanth","Koramangala",25000,25.34f));
		cVectors.add(new Customer("C010","Kiranmayee","Malleswaram",25000,25.34f));
		cVectors.add(new Customer("C011","Kishore","JPNagar",25000,25.34f));
		System.out.println("Size is :"+cVectors.size());
		System.out.println("Capacity  is :"+cVectors.capacity());
	}
	public void fetchVectorElements()
	{
		System.out.println("Size is :"+cVectors.size());
		System.out.println("Capacity  is :"+cVectors.capacity());
		
		Enumeration vectEnumer = cVectors.elements();
		while(vectEnumer.hasMoreElements())
		{
			Customer c = (Customer)vectEnumer.nextElement();
			System.out.println("Customer :"+c);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VectorSample vs = new VectorSample();
		vs.populateVector();
		vs.fetchVectorElements();

	}

}
