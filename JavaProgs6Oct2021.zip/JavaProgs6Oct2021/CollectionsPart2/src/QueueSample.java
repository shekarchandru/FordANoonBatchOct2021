import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {

	Queue myQueue = new PriorityQueue();
	Queue <Customer> custQueue = new PriorityQueue<Customer>();
	
	public void populateMyQueue()
	{
		myQueue.add("Mumbai");
		myQueue.add("Bangalore");
		myQueue.add("Ernakulam");
		myQueue.add("Faridabad");
		myQueue.add("Chandigarh");
		myQueue.add("Ahmedabad");
		
		Customer c1 = new Customer("C001","Harsha","RTNagar",10000,12.34f);
		Customer c2 = new Customer("C002","SreeHarsha","Koramangala",12000,12.56f);
		Customer c3 = new Customer("C003","Harshitha","VijayaNagar",15000,15.34f);
		Customer c4 = new Customer("C004","HarshaVardhan","JayaNagar",20000,20.34f);
		custQueue.add(c1);
		custQueue.add(c2);
		custQueue.add(c3);
		custQueue.add(c4);
		custQueue.add(new Customer("C005","Kiran","Malleswaram",25000,25.34f));
	}
	public void fetchMyQueueObjectsUsingRemove()
	{
		System.out.println("Fetching Queue elements-STrings using Remove");
		while(myQueue.isEmpty() == false)
		{
			String city =  (String)myQueue.remove();
			System.out.println("City is "+city);
		}
		
		System.out.println("Fetching Queue elements-Customer Objects using Remove");
		while(custQueue.isEmpty() == false)
		{
			Customer c = (Customer)custQueue.remove();
			System.out.println("Customer "+c);
		}
		
	}
	public void fetchMyQueueObjectsUsingIterator()
	{
		System.out.println("Fetching Queue elements-STrings using Iterator");
		Iterator qIter = myQueue.iterator();
		while(qIter.hasNext())
		{
			String sCity = (String)qIter.next();
			System.out.println("City is "+sCity);
		}
		
		System.out.println("Fetching Queue elements-Customer Objects using Iterator");
		Iterator qcIter = custQueue.iterator();
		while(qcIter.hasNext())
		{
			Customer cust = (Customer)qcIter.next();
			System.out.println("Customer is "+cust);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueSample qs = new QueueSample();
		qs.populateMyQueue();
		qs.fetchMyQueueObjectsUsingRemove();
		qs.populateMyQueue();
		qs.fetchMyQueueObjectsUsingIterator();
		System.out.println("----------------------");
	}

}
