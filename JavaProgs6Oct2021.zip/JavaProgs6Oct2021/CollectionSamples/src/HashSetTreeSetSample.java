import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

	HashSet myHashSet = new HashSet();
	TreeSet myTreeSet = new TreeSet();
	public void populateHashSet()
	{
		myHashSet.add("Catherine");
		myHashSet.add("Dominic");
		myHashSet.add("Zeenat");
		myHashSet.add("Amarendra");
		myHashSet.add("Emanuel");
		myHashSet.add("Faheem");
		myHashSet.add("Yasmeen");
		myHashSet.add("Jayanth");
		
	}
	public void fetchHashSetObjectsUsingIter()
	{
		
		Iterator hsIter = myHashSet.iterator();
		while(hsIter.hasNext())
		{
			System.out.println("The Object In Hash Set "+hsIter.next());
		}
	}
	public void populateTreeSet()
	{
		myTreeSet.add("Catherine");
		myTreeSet.add("Dominic");
		myTreeSet.add("Zeenat");
		myTreeSet.add("Amarendra");
		myTreeSet.add("Emanuel");
		myTreeSet.add("Faheem");
		myTreeSet.add("Yasmeen");
		myTreeSet.add("Jayanth");
	}
	public void fetchTreeSetObjects()
	{
		Iterator tsIter = myTreeSet.iterator();
		System.out.println("Elements of TreeSet Sorted ...");
		while(tsIter.hasNext())
		{
			System.out.println("The Element is "+tsIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSetTreeSetSample hsts = new HashSetTreeSetSample();
		hsts.populateHashSet();
		hsts.fetchHashSetObjectsUsingIter();
		System.out.println("------------------TreeSet ------------------");
		hsts.populateTreeSet();
		hsts.fetchTreeSetObjects();

	}

}
