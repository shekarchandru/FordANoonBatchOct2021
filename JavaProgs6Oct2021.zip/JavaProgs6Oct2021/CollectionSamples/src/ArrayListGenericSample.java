import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListGenericSample {

	//ArrayList <Customer> myCustomers = new ArrayList<Customer>();
	ArrayList <Customer> customers;
	public void populateGArrayList()
	{
		customers = new ArrayList<Customer>();
		
		Customer c1 = new Customer("C001","Harsha","RTNagar",10000,12.34f);
		Customer c2 = new Customer("C002","SreeHarsha","Koramangala",12000,12.56f);
		Customer c3 = new Customer("C003","Harshitha","VijayaNagar",15000,15.34f);
		Customer c4 = new Customer("C004","HarshaVardhan","JayaNagar",20000,20.34f);
		customers.add(c1);
		customers.add(c2);
		customers.add(c3);
		customers.add(c4);
		customers.add(new Customer("C005","Kiran","Malleswaram",25000,25.34f));
		
		customers.add(2, new Customer("C006","Mohan","RJNagar",20000,20.34f));
		
	}
	public void fetchGArrayListObjects()
	{
		Iterator <Customer> cIter = customers.iterator();
		while(cIter.hasNext())
		{
			Customer c = cIter.next();
			System.out.println("Customer : "+c);
		}
		
	}
	public void removeElement()
	{
		System.out.println("The Size Before  removal "+customers.size());
		customers.remove(2);
		Iterator <Customer> cIter = customers.iterator();
		
		System.out.println("Array List after removal ....");
		while(cIter.hasNext())
		{
			Customer c = cIter.next();
			System.out.println("Customer : "+c);
		}
		System.out.println("The Size after removal "+customers.size());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListGenericSample als = new ArrayListGenericSample();
		als.populateGArrayList();
		als.fetchGArrayListObjects();
		als.removeElement();

	}

}
