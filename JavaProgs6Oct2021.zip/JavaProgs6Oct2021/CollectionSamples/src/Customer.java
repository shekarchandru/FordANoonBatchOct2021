//POJO - PLAIN OLD JAVA OBJECT - MODEL CLASS
public class Customer {

	String customerId;
	String customerName;
	String customerAddress;
	int purchaseValue;
	float salesTax;
	
	
	public Customer() {
		super();
	}


	public Customer(String customerId, String customerName, String customerAddress, int purchaseValue, float salesTax) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.purchaseValue = purchaseValue;
		this.salesTax = salesTax;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", purchaseValue=" + purchaseValue + ", salesTax=" + salesTax + "]";
	}
	
	
}
