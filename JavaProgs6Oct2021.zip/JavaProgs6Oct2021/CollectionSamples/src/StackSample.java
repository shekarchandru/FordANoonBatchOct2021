import java.util.Iterator;
import java.util.Stack;

public class StackSample {
	
	Stack <String> myStack = new Stack<String>();
	public void populateStack()
	{
		myStack.push("Catherine");
		myStack.push("Dominic");
		myStack.push("Zeenat");
		myStack.push("Amarendra");
		myStack.push("Emanuel");
		myStack.push("Faheem");
		myStack.push("Yasmeen");
		myStack.push("Jayanth");
		myStack.push("Kumar");
	}
	public void fetchStackObjectsPop()
	{
		System.out.println("Elements of Stack using POP.......");
		while(myStack.isEmpty() == false)
		{
			String employee =  myStack.pop();
			System.out.println("The Element is "+employee);
		}
		
	}
	public void fetchStackObjectIter()
	{
		Iterator <String> stIter = myStack.iterator();
		System.out.println("Elements of Stack using Iterator...");
		while(stIter.hasNext())
		{
			String stackObj =  stIter.next();
			System.out.println("Element is "+stackObj);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackSample ss = new StackSample();
		ss.populateStack();
		ss.fetchStackObjectsPop();
		System.out.println("-------------------");
		ss.populateStack();
		ss.fetchStackObjectIter();
	}

}
