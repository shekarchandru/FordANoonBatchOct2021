import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {

	ArrayList list1;
	public void populateArrayList()
	{
		list1 = new ArrayList();
		list1.add("Hello World");
		list1.add(20000);
		list1.add(234.45f);
		list1.add(23455.67d);
		list1.add(true);
	}
	public void fetchArrayListObjects()
	{
		Iterator lIter = list1.iterator();
		while(lIter.hasNext())
		{
			System.out.println("The Object is "+lIter.next());
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayListSample als = new ArrayListSample();
		als.populateArrayList();
		als.fetchArrayListObjects();

	}

}
