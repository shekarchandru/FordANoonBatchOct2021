import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

	LinkedList customers = new LinkedList();
	public void populateLinkedList()
	{
		Customer c1 = new Customer("C001","Harsha","RTNagar",10000,12.34f);
		Customer c2 = new Customer("C002","SreeHarsha","Koramangala",12000,12.56f);
		Customer c3 = new Customer("C003","Harshitha","VijayaNagar",15000,15.34f);
		Customer c4 = new Customer("C004","HarshaVardhan","JayaNagar",20000,20.34f);
		customers.add(c1);
		customers.add(c2);
		customers.add(c3);
		customers.add(c4);
		customers.add(new Customer("C005","Kiran","Malleswaram",25000,25.34f));
		
		Customer c6 = new Customer("C006","Kishan","Indiranagar",20000,20.34f);
		Customer c7 = new Customer("C007","Suman","Malleswaram",27000,27.34f);
		
		customers.addFirst(c6);
		customers.addLast(c7);
	
	}
	public void fetchLinkedListObjects()
	{
		Iterator cIter = customers.iterator();
		while(cIter.hasNext())
		{
			Customer c = (Customer)cIter.next();
			System.out.println("Customer :"+c);
			
		}
	}
	public void fetchDescOrder()
	{
		Iterator cIter = customers.descendingIterator();
		while(cIter.hasNext())
		{
			Customer c = (Customer)cIter.next();
			System.out.println("Customer :"+c);
			
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListSample lls = new LinkedListSample();
		lls.populateLinkedList();
		lls.fetchLinkedListObjects();
		System.out.println("----------------Rev Order------------------");
		lls.fetchDescOrder();
	}

}
