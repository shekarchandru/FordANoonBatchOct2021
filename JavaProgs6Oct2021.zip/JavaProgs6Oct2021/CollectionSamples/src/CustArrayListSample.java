import java.util.ArrayList;
import java.util.Iterator;

public class CustArrayListSample {

	ArrayList customers;
	public void populateCustArrayList()
	{
		customers = new ArrayList();
		Customer c1 = new Customer("C001","Harsha","RTNagar",10000,12.34f);
		Customer c2 = new Customer("C002","SreeHarsha","Koramangala",12000,12.56f);
		Customer c3 = new Customer("C003","Harshitha","VijayaNagar",15000,15.34f);
		Customer c4 = new Customer("C004","HarshaVardhan","JayaNagar",20000,20.34f);
		customers.add(c1);
		customers.add(c2);
		customers.add(c3);
		customers.add(c4);
		customers.add(new Customer("C005","Kiran","Malleswaram",25000,25.34f));
		
	}
	public void fetchCustArrayListObjects()
	{
		Iterator cIter = customers.iterator();
		System.out.println("Customer Records are ...");
		while(cIter.hasNext())
		{
			Customer c = (Customer)cIter.next();
			System.out.println("Customer:"+c);
			
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustArrayListSample cals = new CustArrayListSample();
		cals.populateCustArrayList();
		cals.fetchCustArrayListObjects();
	}

}
