import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerializerClass {

	ObjectInputStream ois;
	
	Employee e;
	public void deSerializeFromFile()
	{
		try {
			ois = new ObjectInputStream(new FileInputStream("myEmployee.txt"));
			e = (Employee)ois.readObject();
			System.out.println("The OBject Read "+e);
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DeSerializerClass dsc = new DeSerializerClass();
		dsc.deSerializeFromFile();

	}

}
