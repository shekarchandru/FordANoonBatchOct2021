import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializerClass {

	ObjectOutputStream oos;
	public void serializeToFile()
	{
		try 
		{
			oos = new ObjectOutputStream(new FileOutputStream("myEmployee.txt"));
			Employee e1 = new Employee("E001","Harsha","RTNagar","9838838833",10000,12.34f);
			oos.writeObject(e1);
			oos.flush();
			oos.close();
			System.out.println("We Have Serialized Employee Object successfully...");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SerializerClass sc = new SerializerClass();
		sc.serializeToFile();
	}

}
