
public class WrapperClassSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 = 1000;
		String str1 = "20000";
		int num2 = Integer.parseInt(str1);
		System.out.println("The num2 after string to int conversion "+num2);
		System.out.println("------------------");
		/* following conversion leads to NUmberFormatException
		 * String str11 = "Ten";
		int num22 = Integer.parseInt(str11);
		System.out.println("The num22 after string to int conversion "+num22);
		*/
		String str2 = "2345.45";
		float flt1 = Float.parseFloat(str2);
		System.out.println("flt1 after string to float conversion "+flt1);
		
		String str3 = "2333345.45";
		double dbl1 = Double.parseDouble(str3);
		System.out.println("dbl1 after string to double conversion "+dbl1);
		
		Double d1 = new Double(2393939.34);
		System.out.println("Value type to ref type "+d1);
		
		double d2 = 2393939.34;
		String dblStr = Double.toString(2393939.34);
		System.out.println("Using toString method to convert double to String "+dblStr);

		float f = 23.345f;
		String fltStr = Float.toString(f);
		
		System.out.println("Using toString method to convert float to String "+fltStr);
	}

}
