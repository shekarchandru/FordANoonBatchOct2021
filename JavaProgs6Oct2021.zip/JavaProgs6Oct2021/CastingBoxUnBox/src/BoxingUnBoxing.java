
public class BoxingUnBoxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 100;
		Object o = i; // Implicit Conversion of Value Type to Reference Type- BOXING
		System.out.println("The Value thru Object "+o);
		
		int x = (int)o;//Explicit Conversion of Reference Type to Value TYpe - UNBoxing
		System.out.println("The Value in int after Explicit UNBoxing "+x);
		
	}

}
