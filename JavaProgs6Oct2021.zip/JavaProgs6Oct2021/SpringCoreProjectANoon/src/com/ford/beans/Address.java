package com.ford.beans;

public class Address {
	
		String houseNo;
		String street;
		String area;
		String city;
		String state;
		String pinNo;
		
		public Address(String houseNo, String street, String area, String city, String state, String pinNo) {
			super();
			this.houseNo = houseNo;
			this.street = street;
			this.area = area;
			this.city = city;
			this.state = state;
			this.pinNo = pinNo;
		}

		@Override
		public String toString() {
			return "Address [houseNo=" + houseNo + ", street=" + street + ", area=" + area + ", city=" + city
					+ ", state=" + state + ", pinNo=" + pinNo + "]";
		}
		
		
		

}
