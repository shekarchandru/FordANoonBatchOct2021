package com.ford.collections;

import java.util.List;

public class Answer {

	String ansId;
	String ansBy;
	List <String> answers;
	
	
	public Answer() {
		super();
	}


	public Answer(String ansId, String ansBy, List<String> answers) {
		super();
		this.ansId = ansId;
		this.ansBy = ansBy;
		this.answers = answers;
	}


	@Override
	public String toString() {
		return "Answer [ansId=" + ansId + ", ansBy=" + ansBy + ", answers=" + answers + "]";
	}
	
	
	
	
}
