package com.ford.collections;

import java.util.List;

public class Answer1 {
	
	String ansId;
	String ansBy;
	List <String> answers;
	
	
	public Answer1() {
		super();
	}


	public String getAnsId() {
		return ansId;
	}


	public void setAnsId(String ansId) {
		this.ansId = ansId;
	}


	public String getAnsBy() {
		return ansBy;
	}


	public void setAnsBy(String ansBy) {
		this.ansBy = ansBy;
	}


	public List<String> getAnswers() {
		return answers;
	}


	public void setAnswers(List<String> answers) {
		this.answers = answers;
	}


	@Override
	public String toString() {
		return "Answer1 [ansId=" + ansId + ", ansBy=" + ansBy + ", answers=" + answers + "]";
	}
	
	

}
