package com.ford.collections;

import java.util.Iterator;
import java.util.List;

public class Customer {
	
	String custId;
	String custName;
	String custAddress;
	float purchaseValue;
	List <String> products;
	
	

	public Customer() {
		super();
	}
	
	

	public Customer(String custId, String custName, String custAddress, float purchaseValue, List<String> products) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custAddress = custAddress;
		this.purchaseValue = purchaseValue;
		this.products = products;
	}



	/*
	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public float getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(float purchaseValue) {
		this.purchaseValue = purchaseValue;
	}
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}*/
	public void displayCustomerDetails()
	{
		System.out.println("Customer Details are...");
		System.out.println("Customer Id :"+custId);
		System.out.println("Customer Name :"+custName);
		System.out.println("Customer Address :"+custAddress);
		System.out.println("Customer Purchase Goods worth  :"+purchaseValue);
		System.out.println("Product Details are");
		Iterator <String> prodIter = products.iterator();
		while(prodIter.hasNext())
		{
			String product = prodIter.next();
			System.out.println(product);
		}
		
		
	}
	

}
