package com.ford.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ford.beans.Customer;
import com.ford.beans.Employee;
import com.ford.beans.MyBean;


public class MyClient {
	
	public boolean injectBean()
	{
		boolean flag = false; 
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		MyBean myBean = (MyBean)context.getBean("bean1");
		if(myBean != null)
		{
			String str = myBean.getMessage();
			System.out.println(str);
			flag = true;
		}
		return flag;
		
	}
	public boolean injectEmployeeBean1()
	{
		boolean flag = false; 
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee employee1 = (Employee)context.getBean("emp1");
		if(employee1 != null)
		{
			employee1.displayEmployeeDetails();
			flag = true;
		}
		return flag;
	}
	public boolean injectEmployeeBean2()
	{
		boolean flag = false; 
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee employee2 = (Employee)context.getBean("emp2");
		if(employee2 != null)
		{
			employee2.displayEmployeeDetails();
			flag = true;
		}
		return flag;
	}
	public boolean injectEmployeeBean3()
	{
		boolean flag = false; 
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee employee3 = (Employee)context.getBean("emp3");
		if(employee3 != null)
		{
			employee3.displayEmployeeDetails();
			flag = true;
		}
		return flag;
	}
	public boolean injectCustomer1()
	{
		boolean flag = false; 
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext1.xml");
		Customer customer1 = (Customer)context.getBean("cust1");
		if(customer1 != null)
		{
			customer1.displayCustomerDetails();
			flag = true;
		}
		return flag;
	}
	public boolean injectCustomer2()
	{
		boolean flag = false; 
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext1.xml");
		Customer customer2 = (Customer)context.getBean("cust2");
		if(customer2 != null)
		{
			customer2.displayCustomerDetails();
			flag = true;
		}
		return flag;
	}

	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		MyBean myBean = (MyBean)context.getBean("bean1");
		String str = myBean.getMessage();
		System.out.println(str);
	}

}
