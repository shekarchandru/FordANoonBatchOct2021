package com.ford.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ford.collections.Question;
import com.ford.collections.Question1;
import com.ford.collections.Quiz;

public class QuizClient {
	
	
	public boolean injectQuestion1()
	{
		boolean flag = false;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext3.xml");
		Question question1 = (Question)context.getBean("quest1");
		if(question1 != null)
		{
			question1.displayQuestionAndAnswers();
			flag = true;
		}
		return flag;
	}
	public boolean injectQuestion2()
	{
		boolean flag = false;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext3.xml");
		Question question2 = (Question)context.getBean("quest2");
		if(question2 != null)
		{
			question2.displayQuestionAndAnswers();
			flag = true;
		}
		return flag;
	}
	public boolean injectQuestion3()
	{
		boolean flag = false;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext4.xml");
		Question1 question3 = (Question1)context.getBean("quest3");
		if(question3 != null)
		{
			question3.displayQuestionAndAnswers();
			flag = true;
		}
		return flag;
	}
	public boolean injectQuestion4()
	{
		boolean flag = false;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext4.xml");
		Question1 question4 = (Question1)context.getBean("quest4");
		if(question4 != null)
		{
			question4.displayQuestionAndAnswers();
			flag = true;
		}
		return flag;
	}
	public boolean injectQuizObject1()
	{
		boolean flag = false;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext5.xml");
		Quiz quiz1 = (Quiz)context.getBean("quiz1");
		if(quiz1 != null)
		{
			quiz1.displayQuizDetails();
			flag = true;
		}
		return flag;
		
	}
	public boolean injectQuizObject2()
	{
		boolean flag = false;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext5.xml");
		Quiz quiz2 = (Quiz)context.getBean("quiz2");
		if(quiz2 != null)
		{
			quiz2.displayQuizDetails();
			flag = true;
		}
		return flag;
		
	}

}
