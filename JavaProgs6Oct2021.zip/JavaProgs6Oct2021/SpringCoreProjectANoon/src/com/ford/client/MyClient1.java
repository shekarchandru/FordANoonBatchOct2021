package com.ford.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ford.collections.Customer;

public class MyClient1 {
	public boolean injectCustomerProduct()
	{
		boolean flag = false; 
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext2.xml");
		Customer customer3 = (Customer)context.getBean("cust1");
		if(customer3 != null)
		{
			customer3.displayCustomerDetails();
			flag = true;
		}
		return flag;
	}

}
