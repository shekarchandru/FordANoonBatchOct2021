
public class StaticSample {

	int nonStaticVar;
	static int staticVar;
	public void nonStaticMethod1()
	{
		nonStaticVar++;
		staticVar++;
		System.out.println("The NONSTATICVARIABLE in nonStaticMethod1 :"+nonStaticVar);
		System.out.println("The STATICVARIABLE in nonStaticMethod1 :"+staticVar);
	}
	
	public static void staticMethod1()
	{
		staticVar++;
		System.out.println("The STATICVARIABLE in StaticMethod1 :"+staticVar);
		
	}
	
	public void nonStaticMethod2()
	{
		nonStaticVar++;
		staticVar++;
		System.out.println("The NONSTATICVARIABLE in nonStaticMethod2 :"+nonStaticVar);
		System.out.println("The STATICVARIABLE in nonStaticMethod2 :"+staticVar);
	}
	
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("The STATICVARIABLE in StaticMethod1 :"+staticVar);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

			StaticSample ss1 = new StaticSample();
				StaticSample.staticMethod1(); //staticVar :1
				ss1.nonStaticMethod1();//NonSTaticVar 1 ; staticVar : 2
				ss1.nonStaticMethod2();//NonStaticVar 2 ; staticVar : 3
			StaticSample ss2 = new StaticSample();
				StaticSample.staticMethod2(); //staticVar: 4
				ss2.nonStaticMethod1(); //NonSTaticVar 1 ;staticVar: 5
				ss2.nonStaticMethod2(); //NonSTaticVar 2 ;staticVar: 6
				
	}

}
