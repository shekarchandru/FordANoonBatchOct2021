import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedCharWriterReader {

	BufferedWriter bw;
	BufferedReader br;
	String str = "We are writing chars into Dealers File thru Buffer";
	public void writeCharsThruBuffer()
	{
		try {
			bw = new BufferedWriter(new FileWriter("Dealer.txt"));
			bw.write(str);
			bw.flush();
			bw.close();
			System.out.println("We Have written successfully chars into file thru buffer...");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void readCharsThruBuffer()
	{
		String str;
		try {
			br = new BufferedReader(new FileReader("Dealer.txt"));
			str = br.readLine();
			br.close();
			System.out.println("The Data Read thru buffer is "+str);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedCharWriterReader bcr = new BufferedCharWriterReader();
		//bcr.writeCharsThruBuffer();
		bcr.readCharsThruBuffer();
	}

}
