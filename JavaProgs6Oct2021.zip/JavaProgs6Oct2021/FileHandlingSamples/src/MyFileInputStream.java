import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MyFileInputStream {

	FileInputStream fis;
	byte myBytes[] = new byte[100];
	public void readFromStream()
	{
		try 
		{
			fis = new FileInputStream("customer.txt");
			fis.read(myBytes);
			String myStr = new String(myBytes);
			System.out.println("The Data that was Read from file is :"+myStr);
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyFileInputStream mfis = new MyFileInputStream();
		mfis.readFromStream();

	}

}
