import java.io.BufferedOutputStream;
import java.io.IOException;

public class BuferedStreamWriterSample {

	BufferedOutputStream bos;
	String str = "We are writing into Stream using Buffer...";
	byte myBytes[] = new byte[100];
	public void writeThruBufferToMonitor()
	{
		myBytes = str.getBytes();
		bos = new BufferedOutputStream(System.out);
		try 
		{
			bos.write(myBytes);//Expect this content to be shown on Monitor
			bos.flush();
			System.out.println("We Have Written onto StdO/P File thru Buffer..");
			bos.close();
		//	System.out.println("We Have Written onto StdO/P File thru Buffer..");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BuferedStreamWriterSample bsws = new BuferedStreamWriterSample();
		bsws.writeThruBufferToMonitor();
	}

}
