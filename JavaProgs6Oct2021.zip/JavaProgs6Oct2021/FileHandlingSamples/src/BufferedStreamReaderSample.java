import java.io.BufferedInputStream;
import java.io.IOException;

public class BufferedStreamReaderSample {

	BufferedInputStream bis;
	byte myBytes[] = new byte[100];
	String str;
	public void readThruBufferFromKeyBoard()
	{
		bis = new BufferedInputStream(System.in);
		System.out.println("Enter a String ...");
		try 
		{
			bis.read(myBytes);
			str = new String(myBytes);
			System.out.println("You Entered :"+str);
			bis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamReaderSample bsrs = new BufferedStreamReaderSample();
		bsrs.readThruBufferFromKeyBoard();

	}

}
