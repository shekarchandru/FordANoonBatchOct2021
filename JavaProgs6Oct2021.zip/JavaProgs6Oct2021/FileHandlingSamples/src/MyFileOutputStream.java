import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyFileOutputStream {

	FileOutputStream fos;
	public void writeToStream()
	{
		String str = "We Are writing this text into a file";
		byte myBytes[] = new byte[100];
			try 
			{
				myBytes = str.getBytes();
				fos = new FileOutputStream("customer.txt");
				fos.write(myBytes);
				fos.flush();
				fos.close();
				System.out.println("We Have Written into the file using Binary Stream...");
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  catch(IOException ioe)
			{
				ioe.printStackTrace();
			} catch(Exception ex)
			{
				ex.printStackTrace();
			}
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyFileOutputStream mos = new MyFileOutputStream();
		mos.writeToStream();

	}

}
