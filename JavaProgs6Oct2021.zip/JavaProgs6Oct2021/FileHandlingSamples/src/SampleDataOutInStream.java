import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SampleDataOutInStream {

	DataOutputStream dos;
	DataInputStream dis;
	public void writeThruDataOutputStream()
	{
		try 
		{
			dos = new DataOutputStream(new FileOutputStream("student.txt"));
			dos.writeUTF("Welcome to Streams");
			dos.writeInt(2000);
			dos.writeDouble(2345.567);
			dos.writeBoolean(true);
			
			dos.flush();
			dos.close();
			System.out.println("We Have written into file thru Data Stream");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public void readThruDataInputStream()
	{
		try {
			dis = new DataInputStream(new FileInputStream("student.txt"));
			System.out.println("The String Read is :"+dis.readUTF());
			System.out.println("The Int Data Read is :"+dis.readInt());
			System.out.println("The Double Data read is :"+dis.readDouble());
			System.out.println("The Boolean Data Read is "+dis.readBoolean());
			dis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleDataOutInStream sds = new SampleDataOutInStream();
		//sds.writeThruDataOutputStream();
		sds.readThruDataInputStream();
	}

}
