
public class Calculator {

	public void calculate(int a,int b)
	{
		int result=0;
		System.out.println("We are in the Calculate Function...");
		System.out.println("We are about to Calculate....");
		try
		{
			result  =  a/b;
		}
		catch(ArithmeticException ae)
		{
			System.out.println(ae.getMessage());
			ae.printStackTrace();
		}
		System.out.println("The Result is "+result);
		System.out.println("We just calculated ....");
		
		System.out.println("We are exiting Calculator Function...");
	}
}
