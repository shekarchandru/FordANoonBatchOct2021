package com.ford.cores;

public class WelcomeMessage {

	public String greetMessage()
	{
		return "Welcome to Spring Core";
	}
}
