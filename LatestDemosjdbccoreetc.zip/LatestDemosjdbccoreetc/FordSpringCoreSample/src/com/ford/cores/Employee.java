package com.ford.cores;

public class Employee {
	
		String employeeId;
		String employeeName;
		String employeeAddress;
		String employeePhone;
		float employeeSalary;
		
		
		public Employee() {
			super();
		}


		public Employee(String employeeId, String employeeName, String employeeAddress, String employeePhone,
				float employeeSalary) {
			super();
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.employeeAddress = employeeAddress;
			this.employeePhone = employeePhone;
			this.employeeSalary = employeeSalary;
		}
		public Employee(String employeeId, String employeeName, String employeeAddress, String employeePhone) {
			super();
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.employeeAddress = employeeAddress;
			this.employeePhone = employeePhone;
		}
		
		
		public Employee(String employeeId, String employeeName, String employeeAddress) {
			super();
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.employeeAddress = employeeAddress;
		}

		public void displayEmployee()
		{
			System.out.println("Employee Details are..");
			System.out.println("Employee Id : "+this.employeeId);
			System.out.println("Employee Name "+this.employeeName);
			System.out.println("Employee Address "+this.employeeAddress);
			System.out.println("Employee Phone "+this.employeePhone);
			System.out.println("Employee Salary "+this.employeeSalary);
		}
		
		

}
