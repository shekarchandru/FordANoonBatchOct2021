package com.ford.cores.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ford.cores.Injector;

class InjectorTest {

	static Injector injector;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		injector = new Injector();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

/*	@Test
	void shouldInjectWelcomeMessageObject() {
		assertTrue(injector.getWelcomeObject());
	}
	@Test
	void shouldInjectFirstEmployeeObject() {
		assertTrue(injector.getEmployee1());
	}
	@Test
	void shouldInjectSecondEmployeeObject() {
		assertTrue(injector.getEmployee2());
	}*/
	@Test
	void shouldInjectEmployeeWith4Args() {
		assertTrue(injector.getEmployee3());
	}
	@Test
	void shouldInjectEmployeeWith3Args() {
		assertTrue(injector.getEmployee4());
	}

}
