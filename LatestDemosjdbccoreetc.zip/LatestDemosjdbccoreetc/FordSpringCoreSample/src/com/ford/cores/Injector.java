package com.ford.cores;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Injector {
	
	boolean flag = false;
	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
	
	public boolean getWelcomeObject()
	{
		WelcomeMessage wMessage = (WelcomeMessage)context.getBean("welcome");
		if(wMessage!= null)
		{
			flag = true;
			System.out.println(wMessage.greetMessage());
		}
		return flag;
	}
	public boolean getEmployee1()
	{
		Employee empl1 = (Employee)context.getBean("emp1");
		if( empl1 != null)
		{
			flag = true;
			empl1.displayEmployee();
		}
		return flag;
	}
	public boolean getEmployee2()
	{
		Employee empl2 = (Employee)context.getBean("emp2");
		if( empl2 != null)
		{
			flag = true;
			empl2.displayEmployee();
		}
		return flag;
	}
	public boolean getEmployee3()
	{
		Employee empl3 = (Employee)context.getBean("emp3");
		if( empl3 != null)
		{
			flag = true;
			empl3.displayEmployee();
		}
		return flag;
	}
	public boolean getEmployee4()
	{
		Employee empl4 = (Employee)context.getBean("emp4");
		if( empl4 != null)
		{
			flag = true;
			empl4.displayEmployee();
		}
		return flag;
	}
	
	

}
