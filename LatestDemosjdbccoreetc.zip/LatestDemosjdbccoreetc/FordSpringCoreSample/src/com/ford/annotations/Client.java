package com.ford.annotations;

public interface Client {

	public void getClientData();
}
