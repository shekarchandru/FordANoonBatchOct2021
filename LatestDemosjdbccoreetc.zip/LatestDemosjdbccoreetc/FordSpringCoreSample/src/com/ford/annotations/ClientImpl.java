package com.ford.annotations;

public class ClientImpl implements Client{

	@Override
	public void getClientData() {
		// TODO Auto-generated method stub
		System.out.println("Returning ALl Client Details");
	}

}
