package com.ford.annotations;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SerializationSample {

	public void writeReadObjects()
	{
	ArrayList <Customer> cust = new ArrayList<Customer>();
	cust.add(new Customer("C001","Harsha"));
	cust.add(new Customer("C002","Kishan"));
	Customer[] customers = new Customer[2];
	for(int i=0;i<2;i++)
	{
		customers[i] = new Customer();
	}
	customers[0] = new Customer("C003","Raj");
	customers[1] = new Customer("C004","SuRaj");
	try
	{
	ObjectOutputStream ops = new ObjectOutputStream(new FileOutputStream("cust.txt"));
	ObjectOutputStream ops1 = new ObjectOutputStream(new FileOutputStream("cust1.txt"));
	ops.writeObject(cust);
	ops1.writeObject(customers);
	ops.flush();
	ops.close();
	ops1.flush();
	ops1.close();
	
	}
	catch(FileNotFoundException fnfe)
	{
		fnfe.printStackTrace();
	}
	catch(IOException ioe)
	{
		ioe.printStackTrace();
	}
	
	try
	{
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("cust.txt"));
		ObjectInputStream ois1 = new ObjectInputStream(new FileInputStream("cust1.txt"));
		ArrayList <Customer> customers1 = (ArrayList<Customer>) ois.readObject();
		Customer[] customers2 = (Customer[]) ois1.readObject();
		System.out.println(customers1);
		System.out.println("---------");
		System.out.println(customers2);
		for(int i=0;i<2;i++)
		{
			System.out.println(customers2[i]);
		}
		ois.close();
		ois1.close();
		
	}
	catch(ClassNotFoundException cnfe)
	{
		cnfe.printStackTrace();
	}
	catch(FileNotFoundException fnfe)
	{
		fnfe.printStackTrace();
	}
	catch(IOException ioe)
	{
		ioe.printStackTrace();
	}
	}
	public static void main(String[] args)
	{
		SerializationSample ss = new SerializationSample();
		ss.writeReadObjects();
	}
	
}
