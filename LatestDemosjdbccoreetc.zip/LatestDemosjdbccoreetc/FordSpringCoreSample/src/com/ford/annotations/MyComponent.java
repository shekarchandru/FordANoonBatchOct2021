package com.ford.annotations;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component("component1")
public class MyComponent {
	
	public MyComponent()
	{
		System.out.println("Constructor of this Component Invoked..");
	}
	
	public List <String> getStrings()
	{
		List <String> myList = new ArrayList<String>();
		myList.add("USA");
		myList.add("India");
		myList.add("Japan");
		myList.add("Australia");
		return myList;
		
	}

}
