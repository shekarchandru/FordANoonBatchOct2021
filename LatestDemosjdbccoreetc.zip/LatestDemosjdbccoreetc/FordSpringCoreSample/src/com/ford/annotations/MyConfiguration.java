package com.ford.annotations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyConfiguration {

	@Bean("client1")
	public Client getClient1()
	{
		return new ClientImpl();
	}
}
