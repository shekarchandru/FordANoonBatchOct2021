package com.ford.annotations;


public interface Service {

}
