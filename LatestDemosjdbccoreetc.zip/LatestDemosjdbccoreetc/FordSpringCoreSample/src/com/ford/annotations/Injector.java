package com.ford.annotations;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Injector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext();
        appContext.scan("com.ford.annotations");
        appContext.refresh();
        
        Client client = (Client) appContext.getBean("client1");
        client.getClientData();
        MyComponent mycomp = (MyComponent)appContext.getBean("component1");
       List <String> myStrings = mycomp.getStrings();
       System.out.println(myStrings);
        
	}

}
