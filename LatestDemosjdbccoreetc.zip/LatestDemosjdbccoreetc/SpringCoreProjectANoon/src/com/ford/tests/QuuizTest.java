package com.ford.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ford.client.QuizClient;

class QuuizTest {
	static QuizClient quizClient;
	

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		quizClient = new QuizClient();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

/*	@Test
	void shouldInjectQuizQuest1() {
		
		assertEquals(true,quizClient.injectQuestion1());
	} 

	@Test
	void shouldInjectQuizQuest2() {
		
		assertEquals(true,quizClient.injectQuestion2());
	}
	@Test
	void shouldInjectQuizQuest3() {
		
		assertEquals(true,quizClient.injectQuestion3());
	}
	@Test
	void shouldInjectQuizQuest4() {
		
		assertEquals(true,quizClient.injectQuestion4());
	}
	@Test
	void shouldInjectQuizQuest4() {
		
		assertEquals(true,quizClient.injectQuizObject1());
	}*/
	@Test
	void shouldInjectQuizQuest5() {
		
		assertEquals(true,quizClient.injectQuizObject2());
	}
	
}
