package com.ford.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ford.client.MyClient;
import com.ford.client.MyClient1;

class MyBeanTest {

	static MyClient myClient;
	static MyClient1 myClient1;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		myClient = new MyClient();
		myClient1 = new MyClient1();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

/*	@Test
	void shouldInjectMyBean() {
		
		assertTrue(myClient.injectBean());
		
	}
	
	@Test
	void shouldInjectEmp1Bean()
	{
		assertTrue(myClient.injectEmployeeBean1());
	}
	
	@Test
	void shouldInjectEmp2Bean()
	{
		assertTrue(myClient.injectEmployeeBean2());
	}
	@Test
	void shouldInjectEmp3Bean()
	{
		assertTrue(myClient.injectEmployeeBean3());
	}
	@Test
	void shouldInjectCust1Bean()
	{
		assertTrue(myClient.injectCustomer1());
	}
	@Test
	void shouldInjectCust2Bean()
	{
		assertTrue(myClient.injectCustomer2());
	}*/
	//injectCustomerProduct
	@Test
	void shouldInjectCustProductBean()
	{
		assertTrue(myClient1.injectCustomerProduct());
	}
}
