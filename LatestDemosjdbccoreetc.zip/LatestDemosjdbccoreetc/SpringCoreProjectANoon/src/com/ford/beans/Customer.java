package com.ford.beans;

public class Customer {
	
	String custId;
	String custName;
	String custAddress;
	float purchaseValue;
	Product product;
	
	

	public Customer() {
		super();
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public float getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(float purchaseValue) {
		this.purchaseValue = purchaseValue;
	}
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	public void displayCustomerDetails()
	{
		System.out.println("Customer Details are...");
		System.out.println("Customer Id :"+custId);
		System.out.println("Customer Name :"+custName);
		System.out.println("Customer Address :"+custAddress);
		System.out.println("Customer Purchase Goods worth  :"+purchaseValue);
		System.out.println("Product Detail is "+product);
		
	}
	

}
