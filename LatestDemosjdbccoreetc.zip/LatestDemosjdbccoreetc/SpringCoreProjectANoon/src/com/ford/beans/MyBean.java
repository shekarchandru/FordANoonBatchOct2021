package com.ford.beans;

public class MyBean {
	
	public String getMessage()
	{
		return "Welcome to Spring Core Based Dependency Injection";
	}

}
