package com.ford.beans;

public class Employee {
	
	String empId;
	String empName;
	String empPhone;
	float empSalary;
	float incomeTax;
	Address empAddress;
	
	
	public Employee() {
		super();
	}


	public Employee(String empId, String empName, String empPhone) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empPhone = empPhone;
	}


	public Employee(String empId, String empName, String empPhone, float empSalary, float incomeTax) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empPhone = empPhone;
		this.empSalary = empSalary;
		this.incomeTax = incomeTax;
	}
	
	
	
	public Employee(String empId, String empName, String empPhone, float empSalary, float incomeTax,
			Address empAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empPhone = empPhone;
		this.empSalary = empSalary;
		this.incomeTax = incomeTax;
		this.empAddress = empAddress;
	}


	public void displayEmployeeDetails()
	{
		System.out.println("Employee Details are ....");
		System.out.println("Employee Id :"+empId);
		System.out.println("Employee Name :"+empName);
		System.out.println("Employee Phone :"+empPhone);
		System.out.println("Employee Salary :"+empSalary);
		System.out.println("Employee Tax :"+incomeTax);
		System.out.println("Employee Addresss "+empAddress);
	}
	
	
	

}
