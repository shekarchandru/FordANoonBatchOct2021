package com.ford.collections;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Quiz {
	
	String groupId;
	String topic;
	Map <String,String> questionAns;
	
	public Quiz() {
		super();
	}
	public Quiz(String groupId, String topic, Map<String, String> questionAns) {
		super();
		this.groupId = groupId;
		this.topic = topic;
		this.questionAns = questionAns;
	}

	public void displayQuizDetails()
	{
		System.out.println("The Quiz Details are ");
		System.out.println("Group Id is :"+groupId);
		System.out.println("The Quiz Topic is :"+topic);
		
		Set <String> myKeySet = questionAns.keySet();
		Iterator <String> myKeys = myKeySet.iterator();
		while(myKeys.hasNext())
		{
			String question = myKeys.next();
			System.out.println("The Answer for the Question "+question+" is :"+questionAns.get(question));
		}
	}
	
	
	

}
