package com.ford.collections;

import java.util.Iterator;
import java.util.List;

public class Question1 {

	String questionId;
	String question;
	List <Answer1> answers;
	
	public Question1() {
		super();
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public List<Answer1> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Answer1> answers) {
		this.answers = answers;
	}
	
	public void displayQuestionAndAnswers()
	{
		System.out.println("Question Id is :"+questionId);
		System.out.println("Question is :"+question);
		System.out.println("The Answers are :");
		Iterator <Answer1> ansIter = answers.iterator();
		while(ansIter.hasNext())
		{
			Answer1 answer =ansIter.next();
			System.out.println(answer);
		}
		
	}
	
	
}
