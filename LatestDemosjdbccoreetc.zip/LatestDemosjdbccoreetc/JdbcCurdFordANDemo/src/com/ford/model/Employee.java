package com.ford.model;

import java.util.Date;

public class Employee {
	
	String employeeId;
	String employeeName;
	String employeeAddress;
	String employeePhone;
	Date dateOfJoining;
	float employeeSalary;
	
	public Employee() {
		super();
	}

	public Employee(String employeeId, String employeeName, String employeeAddress, String employeePhone,
			Date dateOfJoining, float employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		this.dateOfJoining = dateOfJoining;
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public String getEmployeePhone() {
		return employeePhone;
	}

	public void setEmployeePhone(String employeePhone) {
		this.employeePhone = employeePhone;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public float getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", employeePhone=" + employeePhone + ", dateOfJoining=" + dateOfJoining
				+ ", employeeSalary=" + employeeSalary + "]";
	}
	
	@Override
	   public boolean equals(Object obj) {
	      if (obj == this) {
	         return true;
	      }
	      if (!(obj instanceof Employee)) {
	         return false;
	      }
	      Employee emp = (Employee) obj;
	      return employeeId.equals(emp.employeeId) 
	    		  && employeeName.equals(emp.employeeName)
	    		  && employeeAddress.equals(emp.employeeAddress)
	    		  && employeePhone.equals(emp.employeePhone)
	    		  && dateOfJoining.equals(emp.dateOfJoining)
	    		  && Float.compare(employeeSalary, emp.employeeSalary) == 0;
	   }
	
	

}
