package com.ford.connections;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SampleConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Connection con;
		String url = "jdbc:mysql://localhost:3306/ford";
		String user = "root";
		String password = "MySQL_@123456";
		Statement stmt;
		
		try {
			// Step 1: Load The driver
			//For SQL SERVER : com.microsoft.sqlserver.jdbc.SQLServerDriver
			// FOR MYSQL following line for driver:
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			stmt = con.createStatement();
			ResultSet rs= stmt.executeQuery("select * from employee1");
			System.out.println("Employee Details are....");
			while(rs.next())
			{
				System.out.println("Employee Id :"+rs.getString(1)+" Employee Name :"+rs.getString(2)+" Employee Address :"+rs.getString(3)+" Employee Phone "+rs.getString(4)+" Date Of Joining :"+rs.getDate(5)+" Employee Salary :"+rs.getFloat(6));
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		
		
	}

}
