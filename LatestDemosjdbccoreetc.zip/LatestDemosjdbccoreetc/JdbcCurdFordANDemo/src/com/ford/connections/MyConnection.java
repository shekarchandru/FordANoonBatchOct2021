package com.ford.connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {

	Connection con;
	String url;
	String user;
	String password;
	public MyConnection()
	{
		url = "jdbc:mysql://localhost:3306/ford";
		user = "root";
		password = "MySQL_@123456";
		con = null;
	}
	public Connection getMyConnection()
	{
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(SQLException sqe) {
			sqe.printStackTrace();
		}
		
		return con;
	}
}
