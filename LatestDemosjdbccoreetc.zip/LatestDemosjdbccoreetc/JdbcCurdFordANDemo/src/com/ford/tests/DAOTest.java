package com.ford.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ford.model.Employee;
import com.ford.service.EmployeeService;

import junit.framework.Assert;

class DAOTest {
	
	static EmployeeService empService;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		empService = new EmployeeService();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

/*	@Test
	void shouldDeleteEmployeeRecord() {
		//Given
		String empId = "E010";
		//Then
		assertTrue(empService.deleteEmployeeByIdSvc(empId));
	}*/
	
	@Test
	void shouldUpdateEmployeeRecord() {
		//Given
		//E007	RakeshKumar	Indiranagar	9839393993	2020-04-23	14000
		String empId = "E007";
		String empJoiningDate = "2020-04-23";
		Employee e = new Employee("E007","RameshKumar","KRNagar","9839391113",stringToDateConverter("2020-04-23"),15000.0f);
		assertTrue(empService.updateEmployeeSvc(e, "E007"));
	
	}
	public static java.util.Date stringToDateConverter(String stringDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(stringDate);
		} catch (ParseException pe) {
			return null;
		}
	}

}
