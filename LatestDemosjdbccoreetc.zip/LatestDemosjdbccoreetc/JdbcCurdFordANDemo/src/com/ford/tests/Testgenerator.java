package com.ford.tests;

public class Testgenerator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//E009
		String eId = "E009";
				String prePartId = eId.substring(0, 1); //E
				String postPartId = eId.substring(1, eId.length()); // 009
				System.out.println(prePartId);
				System.out.println(postPartId);
	}

}
