package com.ford.client;

public class EmployeeUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDataMgmt edmt = new EmployeeDataMgmt();
		edmt.showMenu();
	}

}
