package com.ford.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ford.service.EmployeeService;
import com.ford.service.ProcedureCallerService;
import com.ford.model.Employee;

public class EmployeeDataMgmt {
	
	Scanner scan1;
	String reply;
	String choice;
	EmployeeService empService;
	ProcedureCallerService procService;
	
	String empName,empAddress,empPhone;
	String empDOJ;
	float empSalary;
	
	public EmployeeDataMgmt()
	{
		scan1 = new Scanner(System.in);
		reply = "yes";
		empService = new EmployeeService();
		procService = new ProcedureCallerService();
	}
	
	public void showMenu()
	{
		while( reply.equals("yes") || reply.equals("YES"))
		{
			System.out.println("-------------Employee Data Mgmt Menu-----------------");
			System.out.println("1. View All Employee Records...");
			System.out.println("2. View Employee By ID ...");
			System.out.println("3. Insert Employee ...");
			System.out.println("4. Delete Employee By ID...");
			System.out.println("5. Update Employee ...");
			System.out.println("6. Call Procedure to fetch records ...");
			System.out.println("7. Call Procedure With I/p Parameter to fetch Employee record By Id ...");
			System.out.println("8. Exit Menu //System.exit()");
			
			System.out.println("Enter your Choice..");
			choice = scan1.next();
			
			switch(choice)
			{
				case "1":
				{
					List <Employee> employees = new ArrayList<Employee>();
					employees = empService.getAllEmployeesSvc();
					Iterator <Employee> empIter = employees.iterator();
					System.out.println("The Employee Records are...");
					while(empIter.hasNext())
					{
						Employee e = empIter.next();
						System.out.println(e);
					}
					
					
					break;
				}
				case "2":
				{
					String empId;
					/* Displaying The available Employee Ids.....*/
					List <String> empIds = getEmployeeIds();
					displayEmployeeIds(empIds);
					
					System.out.println("Enter the Id of the Employee, Whose record you wish to see..");
					empId = scan1.next();
					/* Fetching Record only if ID Exists */
					if(checkIdExistence(empId))
					{
						Employee employee = empService.getEmployeeByIdSvc(empId);
						System.out.println(employee);
					}
					else
					{
						System.out.println("Sorry , Entered Employee Id Does not exist...");
					}
					
					
					break;
				}
				case "3":
				{
					/* INSERTION CODE */
					Employee employee = new Employee();
					String empId;
					
					/*System.out.println("Enter the Employee Id ");
					empId = scan1.next();*/
					
					// Auto Generating Employee ID
					empId = generateEmployeeId();
				
					System.out.println("New Employee Id is "+empId);
					/**Calling function to accept Employee Data */
					
					getEmployeeData();
					
					employee.setEmployeeId(empId);
					employee.setEmployeeName(empName);
					employee.setEmployeeAddress(empAddress);
					employee.setEmployeePhone(empPhone);
					employee.setDateOfJoining(stringToDateConverter(empDOJ));
					employee.setEmployeeSalary(empSalary);
					
					if(empService.insertEmployeeSvc(employee))
					{
						System.out.println("Inserted Record Successfully...");
					}
					else
					{
						System.out.println("Insertion Failed...");
					}
					break;
				}
				case "4":
				{
					/* DELETION CODE */
					String employeeId ;
					
					/* Displaying The available Employee Ids.....*/
					List <String> empIds = getEmployeeIds();
					displayEmployeeIds(empIds);
					
					/* ACCEPTING ID */
					System.out.println("Enter the EmployeeId of the Employee whose record you wish to delete..");
					employeeId = scan1.next();
					/* Performing Deletion only If ID Exists... */
					if(checkIdExistence(employeeId))
					{
					
						if(empService.deleteEmployeeByIdSvc(employeeId))
						{
							System.out.println("Deleted Record for the Employee "+employeeId+" Successfully...");
						}
						else
						{
							System.out.println("Deletion Failed...");
						}
					}
					else
					{
						System.out.println("Sorry, Entered Employee Id Does not Exist...");
					}
					break;
				}
				case "5":
				{
					/* UPDATION */
					String employeeId;
					
					/* Displaying The available Employee Ids.....*/
					List <String> empIds = getEmployeeIds();
					displayEmployeeIds(empIds);
					
					
					/* ACCEPTING ID */
					System.out.println("Enter the Id of The Employee Whose details you wish to Update...");
					employeeId = scan1.next(); /* */
					
					/* Performing Updation only If ID Exists... */
					if(checkIdExistence(employeeId))
					{
						Employee e = empService.getEmployeeByIdSvc(employeeId);
						System.out.println("The Current Record for the Id "+employeeId+" is ");
						System.out.println(e);
					
					
						Employee employee = new Employee();
					
						/*Accepting the Employee Details for Updation*/
						getEmployeeData();
					
						//	employee.setEmployeeId(empId);
							employee.setEmployeeId(e.getEmployeeId());
							employee.setEmployeeName(empName);
							employee.setEmployeeAddress(empAddress);
							employee.setEmployeePhone(empPhone);
							employee.setDateOfJoining(stringToDateConverter(empDOJ));
							employee.setEmployeeSalary(empSalary);
	
						if(empService.updateEmployeeSvc(employee, e.getEmployeeId()))
						{
							System.out.println("Updated Record for the Employee with Id "+employeeId);
						}
						else
						{
							System.out.println("Updation Failed...");
						}
					}
					else
					{
						System.out.println("Sorry , Entered Employee Id Does not Exist....");
					}
					
					break;
				}
				case "6":
				{
					List <Employee> employees = procService.fetchEmployeesByProcSvc();
					Iterator <Employee> empIter = employees.iterator();
					System.out.println("Employee Details Fetched thru Procedure...");
					while(empIter.hasNext())
					{
						Employee e = empIter.next();
						System.out.println(e);
					}
					break;
				}
				case "7":
				{
					String employeeId;
					Employee emp = new Employee();
					System.out.println("Enter the Employee Id whose Record you wish to see ...");
					employeeId = scan1.next();
					emp = procService.fetchEmployeeByIdThruProcSvc(employeeId);
					System.out.println("Employee Record fetched for "+employeeId);
					System.out.println(emp);
					break;
				}
				default:
				{
					
					break;
				}
			}
			System.out.println("Do You Wish to Continue Yes / No.");
			reply = scan1.next();
		}
	}
	
	private void getEmployeeData()
	{
		System.out.println("Enter the Employee Name ");
		empName = scan1.next();
		System.out.println("Enter the Employee Address");
		empAddress = scan1.next();
		System.out.println("Enter the Employee Phone..");
		empPhone = scan1.next();
		System.out.println("Enter the Date of Joining in YYYY-MM-DD format");
		empDOJ = scan1.next();
		System.out.println("Enter the Salary");
		empSalary = scan1.nextFloat();
	}
	
	private List <String> getEmployeeIds()
	{
		return empService.getEmployeeIdsSvc();
	}
	
	private void displayEmployeeIds(List <String> empIds)
	{
		Iterator <String> empIdIter = empIds.iterator();
		System.out.println("Available Employee Ids are...");
		while(empIdIter.hasNext())
		{
			System.out.println(empIdIter.next());
		}
	}
	private boolean checkIdExistence(String empId)
	{
		List <String> empIds = getEmployeeIds();
		boolean flag = false;
		Iterator <String> empIdIter = empIds.iterator();
		while(empIdIter.hasNext())
		{
			String emplId = empIdIter.next();
			if(emplId.equals(empId))
			{
				flag = true;
				break;
			}
		}
		return flag;
	}
	/* 
	 * hamburger str.substring(4,8) urge
	 * 
	 * */
	private String generateEmployeeId()
	{
		String generatedId;
		String maxEmpId = empService.getMaxEmployeeIdSvc();
		//E009
		String prePartId = maxEmpId.substring(0, 1); //E
		String postPartId = maxEmpId.substring(1, maxEmpId.length()); // 009
		int postPartIdInt = Integer.parseInt(postPartId);  //9
		int incrementedPostPartId = postPartIdInt+1;//10
		
		if((incrementedPostPartId >= 0) &&(incrementedPostPartId < 10))
		{
			generatedId = "E00"+incrementedPostPartId;
		}
		else if((incrementedPostPartId >= 10) &&(incrementedPostPartId < 100))
		{
			generatedId = "E0"+incrementedPostPartId;
		}
		else if((incrementedPostPartId >= 10) &&(incrementedPostPartId < 100))
		{
			generatedId = "E"+incrementedPostPartId;
		}
		else
		{
			generatedId = "";
		}
		
		return generatedId;
	}
	public static java.util.Date stringToDateConverter(String stringDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(stringDate);
		} catch (ParseException pe) {
			return null;
		}
	}

}
