package com.ford.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ford.connections.MyConnection;
import com.ford.model.Employee;
public class ProcedureCaller {
	
	
	MyConnection myCon;
	Connection con;
	Statement stmt;
	/*PreparedStatement pstmt;*/
	CallableStatement cstmt;
	ResultSet rs;
	
	public ProcedureCaller()
	{
		myCon = new MyConnection();
		con  = myCon.getMyConnection();
	}
	public List <Employee> fetchEmployeesByProc()
	{
		List <Employee> employees = new ArrayList<Employee>();
		try {
			cstmt = con.prepareCall("call fetchEmployeeDetailsProc()");
			rs = cstmt.executeQuery();
			while(rs.next())
			{
				Employee e = new Employee();
				e.setEmployeeId(rs.getString(1));
				e.setEmployeeName(rs.getString(2));
				e.setEmployeeAddress(rs.getString(3));
				e.setEmployeePhone(rs.getString(4));
				e.setDateOfJoining(rs.getDate(5));
				e.setEmployeeSalary(rs.getFloat(6));
				
				employees.add(e);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employees;
		
	}
	public Employee fetchEmployeeByIdThruProc(String empId)
	{
		Employee e = new Employee();
		try {
			cstmt = con.prepareCall("call fetchEmployeeDetailsByIdProc(?)");
			cstmt.setString(1, empId);
			rs = cstmt.executeQuery();
			rs.next();
			
			e.setEmployeeId(rs.getString(1));
			e.setEmployeeName(rs.getString(2));
			e.setEmployeeAddress(rs.getString(3));
			e.setEmployeePhone(rs.getString(4));
			e.setDateOfJoining(rs.getDate(5));
			e.setEmployeeSalary(rs.getFloat(6));
			
		} catch (SQLException sqee) {
			// TODO Auto-generated catch block
			sqee.printStackTrace();
		}
		return e;
	}

}
