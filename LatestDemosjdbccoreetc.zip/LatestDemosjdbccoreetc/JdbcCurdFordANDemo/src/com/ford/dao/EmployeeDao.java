package com.ford.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.ford.model.Employee;
import com.ford.connections.MyConnection;

public class EmployeeDao {
	
	MyConnection myCon;
	Connection con;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public EmployeeDao()
	{
		myCon = new MyConnection();
		con  = myCon.getMyConnection();
	}
	public List <Employee> getAllEmployees()
	{
		con = myCon.getMyConnection();
		List <Employee> employees = new ArrayList<Employee>();
		try 
		{
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from Employee1");
			while(rs.next())
			{
				Employee e = new Employee();
				String empId = rs.getString(1);
				e.setEmployeeId(empId);
				e.setEmployeeName(rs.getString(2));
				e.setEmployeeAddress(rs.getString(3));
				e.setEmployeePhone(rs.getString(4));
				e.setDateOfJoining(rs.getDate(5));
				e.setEmployeeSalary(rs.getFloat(6));
				
				employees.add(e);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employees;
		
	}
	public Employee getEmployeeById(String employeeId)
	{
		Employee emp = new Employee();
		try 
		{
			pstmt = con.prepareStatement("select * from employee1 where employeeId = ?");
			pstmt.setString(1, employeeId);
			rs = pstmt.executeQuery();
			rs.next();
			emp.setEmployeeId(rs.getString(1));
			emp.setEmployeeName(rs.getString(2));
			emp.setEmployeeAddress(rs.getString(3));
			emp.setEmployeePhone(rs.getString(4));
			emp.setDateOfJoining(rs.getDate(5));
			emp.setEmployeeSalary(rs.getFloat(6));
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}
	public boolean insertEmployee(Employee employee)
	{
		boolean flag = false;
		try {
			
			PreparedStatement pstmt = con.prepareStatement("insert into Employee1 values(?,?,?,?,?,?)");
			pstmt.setString(1, employee.getEmployeeId());
			pstmt.setString(2, employee.getEmployeeName());
			pstmt.setString(3, employee.getEmployeeAddress());
			pstmt.setString(4, employee.getEmployeePhone());
			pstmt.setDate(5, utilToSqlDateConverter(employee.getDateOfJoining()));
			pstmt.setFloat(6, employee.getEmployeeSalary());
			
			pstmt.execute();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			flag = false;
		}
		
		return flag;
	}
	public boolean deleteEmployeeById(String employeeId)
	{
		boolean flag = false;
		try 
		{
			pstmt = con.prepareStatement("delete from Employee1 where employeeId = ?");
			pstmt.setString(1, employeeId);
			pstmt.execute();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
	public boolean updateEmployee(Employee employee,String employeeId)
	{
		boolean flag = false;
		try {
			pstmt = con.prepareStatement("update Employee1 set employeeName = ?,employeeAddress = ?,employeePhone = ?, DOJ = ?,employeeSalary = ? where employeeId = ?");
			pstmt.setString(1, employee.getEmployeeName());
			pstmt.setString(2, employee.getEmployeeAddress());
			pstmt.setString(3, employee.getEmployeePhone());
			pstmt.setDate(4, utilToSqlDateConverter(employee.getDateOfJoining()));
			pstmt.setFloat(5, employee.getEmployeeSalary());
			pstmt.setString(6, employeeId);
			
			pstmt.executeUpdate();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
	public List <String> getEmployeeIds()
	{
		List <String> empIds = new ArrayList<String>();
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("select employeeId from Employee1");
			while(rs.next())
			{
				empIds.add(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empIds;
		
	}
	public String getMaxEmployeeId()
	{
		String maxEmpId="";
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery("select max(employeeId) from Employee1");
			rs.next();
			
			maxEmpId = rs.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return maxEmpId;
		
	}
	public static java.util.Date stringToDateConverter(String stringDate) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(stringDate);
		} catch (ParseException pe) {
			return null;
		}
	}
	public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
		java.sql.Date sqlDate = null;
		if (utDate != null) {
			sqlDate = new java.sql.Date(utDate.getTime());
		}
		return sqlDate;
	}

	

}
