package com.ford.service;

import java.util.List;

import com.ford.dao.ProcedureCaller;
import com.ford.model.Employee;

public class ProcedureCallerService {
	
	ProcedureCaller procedureCaller;
	
	public ProcedureCallerService()
	{
		procedureCaller = new ProcedureCaller();
	}

	public List <Employee> fetchEmployeesByProcSvc()
	{
		return procedureCaller.fetchEmployeesByProc();
	}
	public Employee fetchEmployeeByIdThruProcSvc(String empId)
	{
		return procedureCaller.fetchEmployeeByIdThruProc(empId);
	}
}
