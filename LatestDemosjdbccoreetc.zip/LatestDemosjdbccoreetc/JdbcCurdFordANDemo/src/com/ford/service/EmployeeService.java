package com.ford.service;

import java.util.List;

import com.ford.dao.EmployeeDao;
import com.ford.model.Employee;

public class EmployeeService {
	
	EmployeeDao edao;
	
	
	
	public EmployeeService() {
		
		edao = new EmployeeDao();
	}

	public List <Employee> getAllEmployeesSvc()
	{
		return edao.getAllEmployees();
	}
	
	public Employee getEmployeeByIdSvc(String employeeId)
	{
		return edao.getEmployeeById(employeeId);
	}
	public boolean insertEmployeeSvc(Employee employee)
	{
		return edao.insertEmployee(employee);
	}
	public boolean deleteEmployeeByIdSvc(String employeeId)
	{
		return edao.deleteEmployeeById(employeeId);
	}
	public boolean updateEmployeeSvc(Employee employee,String employeeId)
	{
		return edao.updateEmployee(employee, employeeId);
	}
	public List <String> getEmployeeIdsSvc()
	{
		return edao.getEmployeeIds();
	}
	public String getMaxEmployeeIdSvc()
	{
		return edao.getMaxEmployeeId();
	}
	

}
