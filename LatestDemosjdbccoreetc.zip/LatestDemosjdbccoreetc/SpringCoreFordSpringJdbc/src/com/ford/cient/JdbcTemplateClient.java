package com.ford.cient;




import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ford.dao.SupplierDAO;
import com.ford.model.Supplier;


public class JdbcTemplateClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		SupplierDAO supDao = (SupplierDAO)context.getBean("sdao");
		
		/*		int status = supDao.insertSupplier(new Supplier("S002","Kishore","RTNagar",25000));
		System.out.println("Record Insertion Status"+status); */
		
		int status1 = supDao.updateSupplier(new Supplier("S002","Kishore Kumar","KOramangala",35000));
		System.out.println("Record Updation Status "+status1);
		
		/*		int status2 = supDao.deleteSuppler(new Supplier("S002","Kishore Kumar","KOramangala",35000));
		System.out.println("Deletion Status "+status2);*/
	}

}
