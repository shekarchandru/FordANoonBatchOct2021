package com.ford.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.ford.model.Supplier;

public class SupplierDAO {

JdbcTemplate jdbcTemplate;

	
	


	public SupplierDAO() {
		super();
	}

	
	
	public SupplierDAO(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	
	public int insertSupplier(Supplier s)
	{
		
		String query="insert into Supplier values('"+s.getSupplierId()+"','"+s.getSupplierName()+"','"+s.getSupplierAddress()+"','"+s.getSupplyAmount()+"')";  
		int status = jdbcTemplate.update(query);
		return status;
	}
	
	public int updateSupplier(Supplier s)
	{
		 String query="update Supplier set supplierName='"+s.getSupplierName()+"',supplierAddress='"+s.getSupplierAddress()+"',supplyAmount='"+s.getSupplyAmount()+"' where supplierId='"+s.getSupplierId()+"' ";  
		    return jdbcTemplate.update(query); 
	}
	public int deleteSuppler(Supplier s)
	{
		 String query="delete from Supplier where supplierId='"+s.getSupplierId()+"' ";  
		    return jdbcTemplate.update(query);  
	}

}
