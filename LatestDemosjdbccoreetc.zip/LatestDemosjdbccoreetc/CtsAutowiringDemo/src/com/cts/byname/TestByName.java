package com.cts.byname;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestByName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext1.xml");
		WireB wireb = ctx.getBean("wb", WireB.class);
		wireb.displayNew();
	}

}
