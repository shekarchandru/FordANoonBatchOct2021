package com.cts.bytype;

public class WireB {

	WireA wa;

	public WireB() {
		super();
	}

	public WireA getWa() {
		return wa;
	}

	public void setWa(WireA wa) {
		this.wa = wa;
	}
	
	public void display()
	{
		System.out.println("Displaying Wire B");
	}
	public void displayNew()
	{
		wa.display();
		display();
	}
	
}
