package com.cts.bytype;

public class WireA {

	String id;

	public WireA() {
		super();
		System.out.println("WireA Constructor Invoked...");
	}
	public void display()
	{
		System.out.println("Displaying WIRE A features ");
	}
}
