package com.cts.beans;

public class Address {

	String street;
	String area;
	String city;
	String State;
	
	public Address(String street, String area, String city, String state) {
		super();
		this.street = street;
		this.area = area;
		this.city = city;
		State = state;
	}

	@Override
	public String toString() {
		return "Address [street=" + street + ", area=" + area + ", city=" + city + ", State=" + State + "]";
	}
	
	
	
}
