package com.cts.beans;

import java.util.Iterator;
import java.util.List;

public class Question {

	String questionId;
	String question;
	List <Answer> answers;
	
	public Question() {
		super();
	}

	public Question(String questionId, String question, List<Answer> answers) {
		super();
		this.questionId = questionId;
		this.question = question;
		this.answers = answers;
	}
	
	public void displayQuestion()
	{
		System.out.println("The Question Id "+this.questionId);
		System.out.println("The Question is "+this.question);
		Iterator <Answer> ansIter = answers.iterator();
		System.out.println("The Answers Are....");
		while(ansIter.hasNext())
		{
			Answer answer = ansIter.next();
			System.out.println(answer);
		}
		
	}
	
	
	
}
