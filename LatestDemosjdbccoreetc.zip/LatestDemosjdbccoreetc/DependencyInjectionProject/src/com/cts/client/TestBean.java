package com.cts.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cts.beans.EmployeeBean;

public class TestBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		ApplicationContext context1 = new ClassPathXmlApplicationContext("applicationContext.xml");
		EmployeeBean empBean = context1.getBean("emp1", EmployeeBean.class);
		
		//EmployeeBean emp1 = new EmployeeBean();
		
		String str = empBean.welcome();
		System.out.println("Harsha "+str);
		//--------------------ANOTHER METHOD TO LOAD BEANS
		Resource resource = new ClassPathResource("applicationContext.xml");
		BeanFactory myFactory = new XmlBeanFactory(resource);
		EmployeeBean empBean1 = (EmployeeBean)myFactory.getBean("emp2");
		empBean1.getMessage();

	}

}
