package com.cts.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.beans.Question;

public class TestQuiz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		ApplicationContext quiz = new ClassPathXmlApplicationContext("applicationContext2.xml");
		
		Question quest1 = quiz.getBean("q1", Question.class);
		System.out.println("The Question1 Details are-------------");
		quest1.displayQuestion();
		Question quest2 = quiz.getBean("q2", Question.class);
		System.out.println("The Question2 Details are-------------");
		quest2.displayQuestion();
		
	}

}
