package com.cts.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class customerClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext2.xml");
		Customer c1 = ctx.getBean("cust1", Customer.class);
		c1.displayCustomerDetails();
		System.out.println("-------------");
		Customer c2 = ctx.getBean("cust2", Customer.class);
		c2.displayCustomerDetails();
	}

}
