package com.cts.beans;

import java.util.Iterator;
import java.util.List;

public class Customer {

	String customerId;
	String customerName;
	float purchaseValue;
	List <Product> products;
	
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public float getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(float purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Customer() {
		super();
	}
	
	public void displayCustomerDetails()
	{
		System.out.println("Customer Id :"+customerId);
		System.out.println("Customer Name is "+customerName);
		System.out.println("Purchase Goods Worth :"+purchaseValue);
		System.out.println("The Products Purchased Are...");
		Iterator <Product> prodIter = products.iterator();
		while(prodIter.hasNext())
		{
			Product p = prodIter.next();
			System.out.println(p);
		}
	}
	
	
}
