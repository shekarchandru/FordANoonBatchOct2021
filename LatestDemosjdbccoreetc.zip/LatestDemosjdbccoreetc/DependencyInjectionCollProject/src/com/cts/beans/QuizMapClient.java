package com.cts.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuizMapClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext1.xml");
		QuizMap qMap1 = ctx.getBean("quiz1", QuizMap.class);
		qMap1.displayQuizDetails();
		System.out.println("-------------------");
		QuizMap qMap2 = ctx.getBean("quiz2", QuizMap.class);
		qMap2.displayQuizDetails();
		
	}

}
