package com.cts.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuizClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		Quiz quiz1 = ctx.getBean("g1", Quiz.class);
		quiz1.displayQuizDetails();
		System.out.println("------------");
		Quiz quiz2 = ctx.getBean("g2", Quiz.class);
		quiz2.displayQuizDetails();
	}

}
