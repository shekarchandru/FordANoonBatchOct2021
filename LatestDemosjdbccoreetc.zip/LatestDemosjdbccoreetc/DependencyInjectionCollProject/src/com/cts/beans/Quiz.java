package com.cts.beans;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Quiz {
	
	String groupId;
	String topic;
	Map <String,String> questAns;
	
	public Quiz() {
		super();
	}

	public Quiz(String groupId, String topic, Map<String, String> questAns) {
		super();
		this.groupId = groupId;
		this.topic = topic;
		this.questAns = questAns;
	}
	
	public void displayQuizDetails()
	{
		System.out.println("The Quiz Group Id is :"+groupId);
		System.out.println("The Topic is :"+topic);
		
		/*
		Set myKeys = questAns.keySet();
		Iterator myKeyIter = myKeys.iterator();
		while(myKeyIter.hasNext())
		{
			String qkey = (String)myKeyIter.next();
			System.out.println("The Value for the Key "+qkey+" is "+questAns.get(qkey));
		}*/
		
		
		
		Set <Entry <String,String>> mySet = questAns.entrySet();
		Iterator <Entry <String,String>> mySetIter = mySet.iterator();
		while(mySetIter.hasNext())
		{
			Entry <String,String> myEntry = mySetIter.next();
			String quest = myEntry.getKey();
			String answer = myEntry.getValue();
			System.out.println("The Question is "+quest);
			System.out.println("The Answer is "+answer);
		}
	}

}
