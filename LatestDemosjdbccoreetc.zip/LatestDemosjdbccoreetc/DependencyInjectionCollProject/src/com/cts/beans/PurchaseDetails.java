package com.cts.beans;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class PurchaseDetails {

	String counterId;
	String salesMan;
	Map <Customer1,Product> purchases;
	
	public Map<Customer1, Product> getPurchases() {
		return purchases;
	}

	public void setPurchases(Map<Customer1, Product> purchases) {
		this.purchases = purchases;
	}

	public PurchaseDetails() {
		super();
	}

	public String getCounterId() {
		return counterId;
	}

	public void setCounterId(String counterId) {
		this.counterId = counterId;
	}

	public String getSalesMan() {
		return salesMan;
	}

	public void setSalesMan(String salesMan) {
		this.salesMan = salesMan;
	}

	
	
	public void displaySalesDetails()
	{
		System.out.println("The Counter Id is "+counterId);
		System.out.println("The Sales Man is :"+salesMan);
		System.out.println("Customers & Products purchased on this Counter are ");
		
		Set <Entry<Customer1,Product>> mySet = purchases.entrySet();
		
		Iterator <Entry<Customer1,Product>> mySetIter = mySet.iterator();
		while(mySetIter.hasNext())
		{
			 Entry <Customer1,Product> entry = mySetIter.next();
			 Customer1 c = entry.getKey();
			 Product p = entry.getValue();
			 System.out.println("The Customer "+c+" Purchased "+p);
		}
		
		
	}
	
}
