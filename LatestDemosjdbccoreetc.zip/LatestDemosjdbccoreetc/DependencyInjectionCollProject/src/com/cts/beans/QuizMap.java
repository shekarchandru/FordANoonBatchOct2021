package com.cts.beans;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class QuizMap {

	String quizId;
	String topic;
	String question;
	Map  <User,Answer> answers;
	
	public QuizMap() {
		super();
	}

	public QuizMap(String quizId, String topic, String question, Map<User, Answer> answers) {
		super();
		this.quizId = quizId;
		this.topic = topic;
		this.question = question;
		this.answers = answers;
	}
	
	public void displayQuizDetails()
	{
		System.out.println("The Quiz Id is "+quizId);
		System.out.println("The Topic is "+topic);
		System.out.println("The Question is :");
		System.out.println("The Answers and the Users who gave them are :");
		
	//	Set <Entry <User,Answer>> mySet = answers.keySet();
		
	/*	Set keySet = answers.keySet();
		Iterator keySetIter = keySet.iterator();
		while(keySetIter.hasNext())
		{
			User user = (User)keySetIter.next();
			Answer answer = answers.get(user);
			System.out.println("The Answer give by the User "+user+" is :"+answer);
			
		}*/
		
		Set <Entry <User,Answer>> mySet = answers.entrySet();
		Iterator <Entry <User,Answer>> mySetIter = mySet.iterator();
		while(mySetIter.hasNext())
		{
			Entry <User,Answer> entry = mySetIter.next();
			User user = entry.getKey();
			Answer answer = entry.getValue();
			System.out.println("The Answer given by the User "+user+" is :"+answer);
		}
		
	}
	
}
