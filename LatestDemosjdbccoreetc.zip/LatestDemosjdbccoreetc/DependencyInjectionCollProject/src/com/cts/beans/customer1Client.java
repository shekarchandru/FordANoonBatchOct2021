package com.cts.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class customer1Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext3.xml");
		PurchaseDetails pd1 = ctx.getBean("pDet1", PurchaseDetails.class);
		pd1.displaySalesDetails();
		System.out.println("-------------");
		PurchaseDetails pd2 = ctx.getBean("pDet2", PurchaseDetails.class);
		pd2.displaySalesDetails();
	}

}
