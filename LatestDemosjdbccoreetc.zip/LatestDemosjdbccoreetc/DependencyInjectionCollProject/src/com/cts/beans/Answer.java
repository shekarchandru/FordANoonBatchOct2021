package com.cts.beans;

public class Answer {

	String answerId;
	String answer;
	
	
	public Answer() {
		super();
	}


	public Answer(String answerId, String answer) {
		super();
		this.answerId = answerId;
		this.answer = answer;
	}


	@Override
	public String toString() {
		return "Answer [answerId=" + answerId + ", answer=" + answer + "]";
	}
	
	
}
